JASSA
-----

JASSA, Just a Simple Sentiment Analysis Tool for Chinese Text, is a package
for analysing sentiment in traditional Chinese text.


