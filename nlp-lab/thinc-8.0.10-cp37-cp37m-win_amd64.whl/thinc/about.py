__version__ = "8.0.10"
__release__ = True
